Exercícios com GROUP BY

1. Contar o número de produtos por categoria:
Liste o ID da categoria e a quantidade de produtos em cada uma.

SELECT ProductcategoryID, COUNT(ProductID) AS TotalProdutos
FROM SalesLT.Product
GROUP BY ProductcategoryID;


2. Calcular o total de vendas por Produto
Mostre o total de vendas (LineTotal) por Produto (ProductID).

SELECT ProductID, SUM(LineTotal) AS TotalVendas
FROM SalesLT.SalesOrderDetail
GROUP BY ProductID
ORDER BY TotalVendas Desc;


3. Obter a média do preço padrão por categoria:
Liste o ID da categoria e a média do preço padrão (ListPrice) dos produtos em cada categoria.

SELECT ProductCategoryID, AVG(ListPrice) AS MediaPreco
FROM SalesLT.Product
GROUP BY ProductCategoryID;


4. Contar o número de pedidos por status:
Liste o status dos pedidos e o número total de pedidos para cada status.

SELECT Status, COUNT(SalesOrderID) AS TotalPedidos
FROM Sales.SalesOrderHeader
GROUP BY Status;


5. Listar o maior preço padrão por subcategoria:
Liste o maior preço padrão (ListPrice) de produtos em cada subcategoria.

SELECT ProductSubcategoryID, MAX(ListPrice) AS MaiorPreco
FROM Production.Product
GROUP BY ProductSubcategoryID;


6. Contar o número de clientes por território:
Exiba o número total de clientes (CustomerID) em cada território (TerritoryID).

SELECT TerritoryID, COUNT(CustomerID) AS TotalClientes
FROM Sales.Customer
GROUP BY TerritoryID;


7. Calcular o lucro total por produto:
Liste o ID do produto e o lucro total (diferença entre preço e custo multiplicada pela quantidade vendida).

SELECT p.ProductID, 
       SUM((sd.UnitPrice - p.StandardCost) * sd.OrderQty) AS LucroTotal
FROM Sales.SalesOrderDetail sd
JOIN Production.Product p ON sd.ProductID = p.ProductID
GROUP BY p.ProductID;


8. Obter o menor estoque por subcategoria:
Liste o ID da subcategoria e o menor nível de estoque de segurança (SafetyStockLevel) em cada subcategoria.

SELECT ProductSubcategoryID, MIN(SafetyStockLevel) AS MenorEstoque
FROM Production.Product
GROUP BY ProductSubcategoryID;


9. Listar o total de vendas por ano:
Mostre o ano dos pedidos e o total de vendas (TotalDue) para cada ano.

SELECT YEAR(OrderDate) AS Ano, SUM(TotalDue) AS TotalVendas
FROM Sales.SalesOrderHeader
GROUP BY YEAR(OrderDate);


10. Encontrar o número de produtos por faixa de preço:
Classifique os produtos em faixas de preço (ListPrice) e conte quantos produtos estão em cada faixa:

Preço < 50: Faixa "Barato"
Preço entre 50 e 200: Faixa "Moderado"
Preço > 200: Faixa "Caro"

SELECT 
    CASE 
        WHEN ListPrice < 50 THEN 'Barato'
        WHEN ListPrice BETWEEN 50 AND 200 THEN 'Moderado'
        ELSE 'Caro'
    END AS FaixaPreco,
    COUNT(ProductID) AS TotalProdutos
FROM Production.Product
GROUP BY 
    CASE 
        WHEN ListPrice < 50 THEN 'Barato'
        WHEN ListPrice BETWEEN 50 AND 200 THEN 'Moderado'
        ELSE 'Caro'
    END;


11. Calcular o total de pedidos por cliente e território:
Liste o número total de pedidos (SalesOrderID) por cliente (CustomerID) em cada território (TerritoryID).

SELECT TerritoryID, CustomerID, COUNT(SalesOrderID) AS TotalPedidos
FROM Sales.SalesOrderHeader
GROUP BY TerritoryID, CustomerID;


12. Encontrar a data mais recente de pedido por cliente:
Liste o ID do cliente e a data mais recente de um pedido realizado.

SELECT CustomerID, MAX(OrderDate) AS UltimaDataPedido
FROM Sales.SalesOrderHeader
GROUP BY CustomerID;