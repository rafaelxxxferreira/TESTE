-- Manipulações de Texto
/*
	1. Converter texto para maiúsculas ou minúsculas
	Liste os nomes de produtos em maiúsculas e minúsculas.
*/

SELECT 
    Name AS NomeOriginal,
    UPPER(Name) AS NomeMaiusculas,
    LOWER(Name) AS NomeMinusculas
FROM Production.Product;


/*
	2. Concatenar textos
	Exiba os nomes dos produtos concatenados com suas descrições, separados por " - ".
*/

SELECT 
    Name + ' - ' + COALESCE(ProductNumber, 'N/A') AS NomeCompleto
FROM Production.Product;


/*
	3. Extrair parte de um texto
	Extraia os primeiros 5 caracteres do número do produto (ProductNumber).
*/

SELECT 
    ProductNumber,
    LEFT(ProductNumber, 5) AS Primeiros5Caracteres
FROM Production.Product;


/*
	4. Localizar um caractere ou texto
	Encontre a posição do hífen (-) no número do produto.
*/

SELECT 
    ProductNumber,
    CHARINDEX('-', ProductNumber) AS PosicaoHifen
FROM Production.Product
WHERE ProductNumber LIKE '%-%';


/*
	5. Substituir texto
	Substitua os hífens (-) nos números dos produtos por barras (/).
*/

SELECT 
    ProductNumber,
    REPLACE(ProductNumber, '-', '/') AS NumeroAlterado
FROM Production.Product
WHERE ProductNumber LIKE '%-%';


/*
	6. Remover espaços extras
	Remova espaços à esquerda, à direita e no meio do nome do produto.
*/

SELECT 
    Name AS NomeOriginal,
    LTRIM(RTRIM(Name)) AS NomeSemEspacos
FROM Production.Product;


/*
	7. Filtrar texto que começa ou termina com um padrão
	Liste produtos cujo nome começa com "Mountain" e termina com "Bike".
*/

SELECT 
    Name
FROM Production.Product
WHERE Name LIKE 'Mountain%' AND Name LIKE '%Bike';


/*
	8. Contar o número de caracteres
	Conte o número de caracteres no nome dos produtos.
*/

SELECT 
    Name,
    LEN(Name) AS ComprimentoNome
FROM Production.Product;


/*
	9. Dividir texto com base em um delimitador
	Divida os números de produtos nos valores antes e depois do hífen.
*/

SELECT 
    ProductNumber,
    LEFT(ProductNumber, CHARINDEX('-', ProductNumber) - 1) AS ParteAntesDoHifen,
    RIGHT(ProductNumber, LEN(ProductNumber) - CHARINDEX('-', ProductNumber)) AS ParteDepoisDoHifen
FROM SalesLT.Product
WHERE ProductNumber LIKE '%-%';


/*
	10. Substituir valores nulos por texto padrão
	Substitua os valores nulos no número do produto por "Desconhecido".
*/

SELECT 
    ProductID,
    COALESCE(ProductNumber, 'Desconhecido') AS NumeroProdutoCorrigido
FROM Production.Product;


/*
	11. Transformar texto para análise categórica
	Classifique os produtos em categorias com base no nome.
*/

SELECT 
    Name,
    CASE 
        WHEN Name LIKE '%Bike%' THEN 'Bicicleta'
        WHEN Name LIKE '%Helmet%' THEN 'Capacete'
        ELSE 'Outros'
    END AS Categoria
FROM Production.Product;


/*
	12. Combinar colunas de texto para criar uma chave
	Crie uma chave única combinando o ProductID com o nome do produto.
*/

SELECT 
    ProductID,
    Name,
    CAST(ProductID AS NVARCHAR) + '_' + Name AS ChaveUnica
FROM Production.Product;


/*
	13. Padronizar textos curtos com zeros à esquerda
	Adicione zeros à esquerda no ProductID para que todos os IDs tenham 6 caracteres.
*/

SELECT 
    ProductID,
    RIGHT('000000' + CAST(ProductID AS NVARCHAR), 6) AS IDPadronizado
FROM Production.Product;


/*
	14. Encontrar a frequência de um caractere
	Conte quantas vezes o hífen aparece no número do produto.
*/

SELECT 
    ProductNumber,
    LEN(ProductNumber) - LEN(REPLACE(ProductNumber, '-', '')) AS FrequenciaHifen
FROM Production.Product
WHERE ProductNumber LIKE '%-%';


/*
	15. Detectar valores não alfabéticos
	Encontre produtos cujos nomes contenham números.
*/

SELECT 
    Name
FROM Production.Product
WHERE Name LIKE '%[0-9]%';


