/*
 * Como resumir dados por grupos
 * Utilizando a cláusula GROUP BY
 * */

SELECT
	ProductID, 
	COUNT(*) AS qtd_linhas,
	COUNT(OrderQty) AS qtd_linhas_nao_nulas,
	-- Medidas de posição
	MIN(OrderQty) AS qtd_minima,
	AVG(OrderQty) AS qtd_media,
	MAX(OrderQty) AS qtd_maxima
	-- Medidas de dispersão
	--STDDEV(OrderQty) AS desvio_padrao_qtd,
	--VARIANCE(OrderQty) AS variancia_qtd
From SalesLT.SalesOrderDetail sod 
GROUP BY ProductID
HAVING AVG(OrderQty) >= 5
ORDER BY AVG(OrderQty) DESC
