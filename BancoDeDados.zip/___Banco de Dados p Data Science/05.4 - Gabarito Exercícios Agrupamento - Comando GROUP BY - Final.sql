/*
	Exercícios com GROUP BY
	
	1. Contar o número de produtos por categoria:
	Liste o ID da categoria e a quantidade de produtos em 
	cada uma.
*/

SELECT 
	ProductCategoryID, 
	COUNT(*) AS qtd_produto
FROM SalesLT.Product p 
GROUP BY ProductCategoryID


/*
	2. Calcular o total de vendas por Produto
	Mostre o total de vendas (LineTotal) por Produto (ProductID). 
*/

SELECT 
	ProductID, 
	ROUND(SUM(LineTotal),2) AS total_vendas
FROM SalesLT.SalesOrderDetail sod 
GROUP BY ProductID 


/*
  	3. Obter a média do preço padrão por categoria:
		Liste o ID da categoria e a média do preço padrão (ListPrice) dos produtos em 
		cada categoria.
 */

SELECT
	ProductCategoryID,
	AVG(ListPrice) AS media_preco 
FROM SalesLT.Product p 
GROUP BY ProductCategoryID


/*
  	4. Encontrar o número de produtos por faixa de preço:
	Classifique os produtos em faixas de preço (ListPrice) e conte 
	quantos produtos estão em cada faixa:
	
	Preço < 100: Faixa "Barato"
	Preço entre 100 e 500: Faixa "Moderado"
	Preço > 500: Faixa "Caro"
 */

SELECT 
    CASE 
        WHEN ListPrice < 100 THEN 'Barato'
        WHEN ListPrice BETWEEN 100 AND 500 THEN 'Moderado'
        ELSE 'Caro'
    END AS FaixaPreco,
    COUNT(ProductID) AS TotalProdutos
FROM SalesLT.Product
GROUP BY 
    CASE 
        WHEN ListPrice < 100 THEN 'Barato'
        WHEN ListPrice BETWEEN 100 AND 500 THEN 'Moderado'
        ELSE 'Caro'
    END


/*
 	5. Encontrar a data mais recente de pedido por cliente:
		Liste o ID do cliente e a data mais recente de um pedido realizado.
 */
    
SELECT 
	CustomerID, 
	MAX(OrderDate) AS UltimaDataPedido
FROM SalesLT.SalesOrderHeader
GROUP BY CustomerID

 
 /*
	6. Calcular o total de pedidos por cliente 
 */
SELECT 
	CustomerID, 
	COUNT(SalesOrderID) AS TotalPedidos
FROM SalesLT.SalesOrderHeader
GROUP BY CustomerID

/*
	7. Listar o total de vendas por ano:
		Mostre o ano dos pedidos e o total de vendas (TotalDue) para cada ano.
*/
SELECT 
	YEAR(OrderDate) AS Ano, 
	SUM(TotalDue) AS TotalVendas
FROM SalesLT.SalesOrderHeader
GROUP BY YEAR(OrderDate)





