/*
 * Agregando dados
 * Medidas resumo com o SQL
 * 
 * O que quero saber?
 * 	Quais são as medidas resumo da variável OrderQty (qtd de produto) na tabela SalesOrderDetail
 * */

SELECT
	COUNT(*) AS qtd_linhas,
	COUNT(OrderQty) AS qtd_linhas_nao_nulas,
	-- Medidas de posição
	MIN(OrderQty) AS qtd_minima,
	AVG(OrderQty) AS qtd_media,
	MAX(OrderQty) AS qtd_maxima,
	-- Medidas de dispersão
	STDEV(OrderQty) AS desvio_padrao_qtd,
	VAR(OrderQty) AS variancia_qtd
From SalesLT.SalesOrderDetail sod 