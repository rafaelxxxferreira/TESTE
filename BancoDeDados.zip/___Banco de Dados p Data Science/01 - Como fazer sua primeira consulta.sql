/*
 * O que eu quero saber?
 * Nome do Cliente (FirstName)
 * Sobrenome do Cliente (LastName)
 * E-mail do Cliente (EmailAddress)
 * 
 * Onde está a informação?
 * Banco de dados da empresa: 'aula'
 * Tabela: SalesLT.Customer
 */

/*
 * Primeira Consulta
 */
SELECT
	FirstName,
	LastName,
	EmailAddress
FROM
	[SalesLT].[Customer]
	

/*
 * Como personalizar o nome das colunas
 */
SELECT
	FirstName AS nome,
	LastName AS sobrenome,
	EmailAddress AS email
FROM
	[SalesLT].[Customer]
	

/*
 * Como limitar a quantidade de linhas
 */
SELECT Top 10
	FirstName AS nome,
	LastName AS sobrenome,
	EmailAddress AS email
FROM
	[SalesLT].[Customer]