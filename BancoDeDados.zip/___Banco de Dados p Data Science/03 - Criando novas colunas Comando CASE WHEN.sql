/*
	Criando nova colunas / variáveis
	Utilizando o comando CASE WHEN
*/
Select
	Case
		When UnitPriceDiscount != 0 then 1
		Else 0
	End As teve_desconto,
	OrderQty,
	UnitPrice,
	UnitPriceDiscount,
	LineTotal,
	(UnitPrice * OrderQty) * UnitPriceDiscount As DiscountValue
From [SalesLT].[SalesOrderDetail]


/*

	Criando nova colunas / variáveis
	Utilizando o comando CASE WHEN
	
	Categorizar produtos por faixa de preço:
	Liste os produtos e categorize-os em "Barato" (preço < 50), "Moderado" (entre 50 e 200), e "Caro" (acima de 200).

*/

SELECT 
    Name, 
    ListPrice,
    CASE 
        WHEN ListPrice < 100 THEN 'Barato'
        WHEN ListPrice BETWEEN 100 AND 500 THEN 'Moderado'
        ELSE 'Caro'
    END AS CategoriaPreco
FROM SalesLT.Product;