-- Resumo Pedido
SELECT 
	SalesOrderID,
	OrderDate,
	CustomerID,
	SubTotal,	
	TotalDue	
FROM SalesLT.SalesOrderHeader soh 

-- Itens Pedido
SELECT 
	SalesOrderID,
	SalesOrderDetailID,
	ProductID,
	LineTotal 
FROM SalesLT.SalesOrderDetail sod 

-- Cliente e Resumo Pedido e Itens do Pedido
SELECT 
	soh.SalesOrderID,
	OrderDate,
	soh.CustomerID,
	c.FirstName,
	SubTotal,
	TotalDue,
	SalesOrderDetailID,
	sod.ProductID,
	p.Name,
	UnitPriceDiscount,
	OrderQty,
	UnitPrice, 
	LineTotal
FROM SalesLT.SalesOrderHeader soh 
	JOIN SalesLT.SalesOrderDetail sod 
		ON soh.SalesOrderID = sod.SalesOrderID
	JOIN SalesLT.Product p 
		ON sod.ProductID = p.ProductID 
	JOIN SalesLT.Customer c 
		ON soh.CustomerID = c.CustomerID 