Exemplo 1: Média de vendas por produto
Calcule a média de quantidade de vendas por produto.

SELECT 
    p.Name AS ProductName,
    AVG(sod.OrderQty) AS AverageQuantitySold
FROM 
    Production.Product p
INNER JOIN 
    Sales.SalesOrderDetail sod
ON 
    p.ProductID = sod.ProductID
GROUP BY 
    p.Name;


Exemplo 2: Total de vendas por ano e mês
Liste o total de vendas (em valor) por ano e mês.

SELECT 
    YEAR(soh.OrderDate) AS Year,
    MONTH(soh.OrderDate) AS Month,
    SUM(sod.LineTotal) AS TotalSales
FROM 
    Sales.SalesOrderHeader soh
INNER JOIN 
    Sales.SalesOrderDetail sod
ON 
    soh.SalesOrderID = sod.SalesOrderID
GROUP BY 
    YEAR(soh.OrderDate),
    MONTH(soh.OrderDate)
ORDER BY 
    Year, Month;


Exemplo 3: Produtos mais vendidos por categoria
Liste os produtos mais vendidos de cada categoria.

SELECT 
    pc.Name AS CategoryName,
    p.Name AS ProductName,
    SUM(sod.OrderQty) AS TotalQuantitySold
FROM 
    Production.Product p
INNER JOIN 
    Production.ProductSubcategory psc
ON 
    p.ProductSubcategoryID = psc.ProductSubcategoryID
INNER JOIN 
    Production.ProductCategory pc
ON 
    psc.ProductCategoryID = pc.ProductCategoryID
INNER JOIN 
    Sales.SalesOrderDetail sod
ON 
    p.ProductID = sod.ProductID
GROUP BY 
    pc.Name,
    p.Name
ORDER BY 
    pc.Name,
    TotalQuantitySold DESC;







