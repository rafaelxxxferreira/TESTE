/*
	Como filtrar linhas no SQL
	Múltiplos filtros simultâneos
	Operador OR
*/
Select 
	*
From [SalesLT].[Product]
where ListPrice > 1200 OR Color = 'Black'

/*
	Como filtrar linhas no SQL
	Múltiplos filtros simultâneos
	Operador AND
*/
Select 
	*
From [SalesLT].[Product]
where ListPrice > 1200 AND Color = 'Black'


/*
	Como filtrar linhas no SQL
	Múltiplos filtros simultâneos
	Operador BETWEEN
*/
Select 
	*
From [SalesLT].[Product]
where ListPrice BETWEEN 1200 AND 1900 


/*
	Como filtrar linhas no SQL
	Múltiplos filtros simultâneos
	Operador BETWEEN
*/
Select 
	*
From [SalesLT].[Product]
where ListPrice BETWEEN 1200 AND 1900 AND COLOR = 'Black'

/*
	Como filtrar linhas no SQL
	Múltiplos filtros simultâneos
	Operador BETWEEN
*/
Select 
	*
From [SalesLT].[Product]
where (Name LIKE '%Bike%' OR COLOR = 'Black')
	AND ListPrice BETWEEN 1200 AND 1900 

