-- Manipulações de Números

/*
	1. Arredondar valores
	Arredonde os preços padrão (ListPrice) para 2 casas decimais.
*/

SELECT 
    ProductID,
    ListPrice AS PrecoOriginal,
    ROUND(ListPrice, 2) AS PrecoArredondado
FROM SalesLT.Product;


/*
	2. Truncar valores
	Trunque os preços padrão para 2 casas decimais, sem arredondar.
*/

SELECT 
    ProductID,
    ListPrice AS PrecoOriginal,
    ROUND(ListPrice, 2, 1) AS PrecoTruncado
FROM SalesLT.Product;


/*
	3. Calcular porcentagem
	Calcule o percentual de desconto aplicado em cada pedido (UnitPriceDiscount).
*/

SELECT 
    SalesOrderID,
    ProductID,
    UnitPrice,
    UnitPriceDiscount,
    (UnitPriceDiscount / UnitPrice) * 100 AS PercentualDesconto
FROM SalesLT.SalesOrderDetail
WHERE UnitPriceDiscount > 0;


/*
	4. Gerar números aleatórios
	Gere um número aleatório para cada produto entre 1 e 100.
*/

SELECT 
    ProductID,
    Name,
    ABS(CHECKSUM(NEWID())) % 100 + 1 AS NumeroAleatorio
FROM SalesLT.Product;


/*
	5. Calcular o valor absoluto
	Obtenha o valor absoluto da diferença entre StandardCost e ListPrice.
*/

SELECT 
    ProductID,
    StandardCost,
    ListPrice,
    ABS(ListPrice - StandardCost) AS DiferencaAbsoluta
FROM SalesLT.Product;


/*
	6. Elevar valores ao quadrado
	Calcule o quadrado do preço padrão (ListPrice).
*/

SELECT 
    ProductID,
    ListPrice,
    POWER(ListPrice, 2) AS QuadradoPreco
FROM SalesLT.Product;


/*
	7. Calcular a raiz quadrada
	Obtenha a raiz quadrada do preço padrão (ListPrice).
*/

SELECT 
    ProductID,
    ListPrice,
    SQRT(ListPrice) AS RaizQuadradaPreco
FROM SalesLT.Product
WHERE ListPrice > 0;


/*
	8. Aplicar divisão e resto
	Divida o preço padrão (ListPrice) por 10 e mostre o quociente e o resto.
*/

SELECT 
    ProductID,
    ListPrice,
    ListPrice / 10 AS Quociente,
    ListPrice % 10 AS Resto
FROM SalesLT.Product;


/*
	9. Classificar números em intervalos
	Classifique os produtos em faixas de preço padrão (ListPrice).
*/

SELECT 
    ProductID,
    ListPrice,
    CASE 
        WHEN ListPrice < 50 THEN 'Barato'
        WHEN ListPrice BETWEEN 50 AND 200 THEN 'Moderado'
        ELSE 'Caro'
    END AS FaixaPreco
FROM SalesLT.Product;


/*
	10. Calcular agregados básicos
	Calcule o valor mínimo, máximo, médio e a soma dos preços padrão.
*/

SELECT 
    MIN(ListPrice) AS PrecoMinimo,
    MAX(ListPrice) AS PrecoMaximo,
    AVG(ListPrice) AS PrecoMedio,
    SUM(ListPrice) AS SomaPrecos
FROM SalesLT.Product;


/*
	11. Normalizar valores
	Normalize os preços padrão (ListPrice) para um intervalo de 0 a 1.
*/

WITH Precos AS (
    SELECT 
        ProductID,
        ListPrice,
        MIN(ListPrice) OVER () AS PrecoMinimo,
        MAX(ListPrice) OVER () AS PrecoMaximo
    FROM SalesLT.Product
)
SELECT 
    ProductID,
    ListPrice,
    (ListPrice - PrecoMinimo) * 1.0 / (PrecoMaximo - PrecoMinimo) AS PrecoNormalizado
FROM Precos;


/*
	12. Ordenar por valores calculados
	Liste os produtos ordenados pela margem de lucro (diferença entre ListPrice e StandardCost).
*/

SELECT 
    ProductID,
    Name,
    ListPrice,
    StandardCost,
    ListPrice - StandardCost AS MargemLucro
FROM SalesLT.Product
ORDER BY MargemLucro DESC;


/*
	13. Agrupar por faixas de números
	Conte o número de produtos em diferentes faixas de estoque (SafetyStockLevel).
*/
/*
SELECT 
    CASE 
        WHEN SafetyStockLevel < 50 THEN 'Baixo Estoque'
        WHEN SafetyStockLevel BETWEEN 50 AND 100 THEN 'Estoque Moderado'
        ELSE 'Alto Estoque'
    END AS FaixaEstoque,
    COUNT(ProductID) AS TotalProdutos
FROM SalesLT.Product
GROUP BY 
    CASE 
        WHEN SafetyStockLevel < 50 THEN 'Baixo Estoque'
        WHEN SafetyStockLevel BETWEEN 50 AND 100 THEN 'Estoque Moderado'
        ELSE 'Alto Estoque'
    END;

*/
/*
	14. Calcular desvios padrão
	Obtenha o desvio padrão e a variância dos preços padrão (ListPrice).
*/

SELECT 
    STDEV(ListPrice) AS DesvioPadraoPreco,
    VAR(ListPrice) AS VarianciaPreco
FROM SalesLT.Product;


/*
	15. Comparar proporções
	Calcule a proporção do preço de custo (StandardCost) sobre o preço padrão (ListPrice) para cada produto.
*/

SELECT 
    ProductID,
    StandardCost,
    ListPrice,
    (StandardCost * 1.0 / ListPrice) * 100 AS ProporcaoCustoParaPreco
FROM SalesLT.Product
WHERE ListPrice > 0;





