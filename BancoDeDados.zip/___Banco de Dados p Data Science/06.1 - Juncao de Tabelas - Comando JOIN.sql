-- Produto
SELECT 
	ProductID,
	ProductCategoryID,
	Name,
	ListPrice 
FROM SalesLT.Product p 

-- Categoria
SELECT 
	ProductCategoryID,
	Name 
FROM SalesLT.ProductCategory pc 

-- Produto e Categoria
SELECT 
	ProductID,
	p.ProductCategoryID,
	p.Name AS ProductName,
	pc.Name AS CategoryName,
	ListPrice 
FROM SalesLT.Product p 
	JOIN SalesLT.ProductCategory pc 
		ON p.ProductCategoryID = pc.ProductCategoryID 
		
		