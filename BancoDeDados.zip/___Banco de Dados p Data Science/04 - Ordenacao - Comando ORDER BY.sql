/*
	Ordenando as linhas de uma consulta 
	Utilizando o Comando ORDER BY
*/

Select Top 100
	SalesOrderID,
	Case
		When UnitPriceDiscount != 0 then 1
		Else 0
	End As teve_desconto,
	OrderQty,
	UnitPrice,
	UnitPriceDiscount,
	LineTotal,
	(UnitPrice * OrderQty) * UnitPriceDiscount As DiscountValue
From [SalesLT].[SalesOrderDetail]
Order By LineTotal Desc



SELECT ProductID, Name, ProductCategoryID, ListPrice 
FROM SalesLT.Product 
ORDER BY ProductCategoryID ASC, ListPrice DESC;


SELECT ProductID, Name, ListPrice, StandardCost, (ListPrice - StandardCost) AS MargemLucro 
FROM SalesLT.Product 
ORDER BY MargemLucro DESC;