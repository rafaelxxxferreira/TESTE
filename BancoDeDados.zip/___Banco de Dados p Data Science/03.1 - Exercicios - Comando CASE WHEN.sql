/*

	➡️ Exercícios: CASE WHEN

	Exercício 1) 
	Categorizar produtos por faixa de preço:
	Liste os produtos e categorize-os em "Barato" (preço < 50), "Moderado" (entre 50 e 200), e "Caro" (acima de 200).

*/

SELECT 
    Name, 
    ListPrice,
    CASE 
        WHEN ListPrice < 100 THEN 'Barato'
        WHEN ListPrice BETWEEN 100 AND 500 THEN 'Moderado'
        ELSE 'Caro'
    END AS CategoriaPreco
FROM SalesLT.Product;

/*

	Exercício 2) 
	Identificar pedidos com status personalizado:
	Mostre os pedidos com um status customizado baseado no campo Status.

	Status = 1: "Aprovado"
	Status = 2: "Em Processamento"
	Status = 3: "Finalizado"
	Outros valores: "Indefinido"

*/

SELECT 
    SalesOrderID,
    Status,
    CASE 
        WHEN Status = 1 THEN 'Aprovado'
        WHEN Status = 2 THEN 'Em Processamento'
        WHEN Status = 3 THEN 'Finalizado'
        ELSE 'Indefinido'
    END AS StatusDescricao
FROM SalesLT.SalesOrderHeader;

/*
	Exercício 3) 
	Calcular descontos por faixa de valor total:
	Liste os pedidos e aplique um desconto fictício baseado no valor total:

	Total <= 1000: 5%
	Total entre 1001 e 5000: 10%
	Total > 5000: 15%

*/

SELECT 
    SalesOrderID,
    TotalDue,
    CASE 
        WHEN TotalDue <= 1000 THEN TotalDue * 0.05
        WHEN TotalDue BETWEEN 1001 AND 5000 THEN TotalDue * 0.10
        ELSE TotalDue * 0.15
    END AS Desconto
FROM SalesLT.SalesOrderHeader;
