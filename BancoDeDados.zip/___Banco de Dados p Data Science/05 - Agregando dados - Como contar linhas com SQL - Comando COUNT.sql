/*
 * Como contar linhas com SQL
 * Funções de agregação: COUNT
 * 
 * O que quero saber?
 * 	Quantas vendas foram realizadas?
 * */

Select 
	count(SalesOrderID) AS qtd_linhas, -- valores não nulos
	count(*) AS qtd_linhas1,
	count(1) AS qtd_linhas2,
	count(Comment) AS Comentario
From SalesLT.SalesOrderHeader


/*
 * Como contar linhas com SQL
 * Contar grupos de uma categoria
 * 
 * O que quero saber?
 * 	Quantos produtos da cor 'Black'?
 * */

SELECT
	COUNT(ProductID) AS qtd_produto,
	COUNT(Case 
		When Color = 'Black' THEN Color		
	END) AS qtd_produto_black 
From SalesLT.Product p 






