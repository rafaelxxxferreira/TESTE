-- Como Trabalhar com Valores Nulos

/*
	1. Substituir valores nulos por um padrão
	Substitua valores nulos no campo Weight por 0.
*/

SELECT 
    ProductID,
    Name,
    COALESCE(Weight, 0) AS PesoCorrigido
FROM SalesLT.Product;


/*
	2. Identificar registros com valores nulos
	Liste todos os produtos cujo peso (Weight) está ausente.
*/

SELECT 
    ProductID,
    Name,
    Weight
FROM SalesLT.Product
WHERE Weight IS NULL;


/*
	3. Contar valores nulos
	Conte quantos registros têm o campo Weight como nulo.
*/

SELECT 
    COUNT(*) AS TotalValoresNulos
FROM SalesLT.Product
WHERE Weight IS NULL;


/*
	4. Contar valores não nulos
	Conte quantos registros possuem o campo Weight preenchido.
*/

SELECT 
    COUNT(Weight) AS TotalValoresNaoNulos
FROM SalesLT.Product;


/*
	5. Substituir nulos com base em outro valor
	Substitua valores nulos em Weight pelo valor médio dos pesos.
*/

SELECT 
    ProductID,
    Name,
    COALESCE(Weight, (SELECT AVG(Weight) FROM SalesLT.Product WHERE Weight IS NOT NULL)) AS PesoCorrigido
FROM SalesLT.Product;


/*
	6. Excluir registros com valores nulos
	Liste todos os produtos excluindo aqueles cujo peso (Weight) é nulo.
*/

SELECT 
    ProductID,
    Name,
    Weight
FROM SalesLT.Product
WHERE Weight IS NOT NULL;


/*
	7. Atualizar valores nulos
	Atualize os valores nulos em Weight para 0.
*/

UPDATE SalesLT.Product
SET Weight = 0
WHERE Weight IS NULL;


/*
	8. Criar categorias com base em valores nulos
	Classifique os produtos como "Definido" ou "Não Definido" com base na presença de valores no campo Weight.
*/

SELECT 
    ProductID,
    Name,
    CASE 
        WHEN Weight IS NULL THEN 'Não Definido'
        ELSE 'Definido'
    END AS StatusPeso
FROM SalesLT.Product;


/*
	9. Verificar a proporção de valores nulos
	Calcule o percentual de valores nulos no campo Weight.
*/

SELECT 
    (CAST(SUM(CASE WHEN Weight IS NULL THEN 1 ELSE 0 END) AS FLOAT) / COUNT(*)) * 100 AS PercentualValoresNulos
FROM SalesLT.Product;


/*
	10. Substituir nulos com valores calculados por grupo
	Substitua valores nulos no campo Weight pelo peso médio dentro de cada subcategoria.
*/

SELECT 
    ProductID,
    Name,
    ProductCategoryID ,
    COALESCE(Weight, AVG(Weight) OVER (PARTITION BY ProductCategoryID)) AS PesoCorrigidoPorGrupo
FROM SalesLT.Product;


/*
	11. Marcar valores nulos para análise
	Adicione uma coluna temporária indicando se o peso (Weight) está ausente.
*/

SELECT 
    ProductID,
    Name,
    Weight,
    CASE 
        WHEN Weight IS NULL THEN 1
        ELSE 0
    END AS PesoNulo
FROM SalesLT.Product;


/*
	12. Remover duplicatas considerando valores nulos
	Liste os produtos com o menor ProductID em casos de duplicidade no nome, tratando valores nulos como iguais.
*/

SELECT 
    MIN(ProductID) AS ProductID,
    Name
FROM SalesLT.Product
GROUP BY Name;


/*
	13. Comparar colunas com valores nulos
	Liste os produtos onde Weight é nulo e SafetyStockLevel é maior que 50.
*/

SELECT 
    ProductID,
    Name,
    Weight,
    SafetyStockLevel
FROM SalesLT.Product
WHERE Weight IS NULL AND SafetyStockLevel > 50;


/*
	14. Contar valores nulos por coluna
	Conte quantos valores nulos existem em todas as colunas da tabela Product.
*/

SELECT 
    SUM(CASE WHEN Weight IS NULL THEN 1 ELSE 0 END) AS NulosWeight,
    -- SUM(CASE WHEN ProductLine IS NULL THEN 1 ELSE 0 END) AS NulosProductLine,
    SUM(CASE WHEN Color IS NULL THEN 1 ELSE 0 END) AS NulosColor
FROM SalesLT.Product;


/*
	15. Substituir nulos em múltiplas colunas
	Substitua valores nulos em Weight e Color por 0 e 'Desconhecido', respectivamente.
*/

SELECT 
    ProductID,
    Name,
    COALESCE(Weight, 0) AS PesoCorrigido,
    COALESCE(Color, 'Desconhecido') AS CorCorrigida
FROM SalesLT.Product;





