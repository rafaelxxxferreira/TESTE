/*
	Criação do Esquema Estrela
	1. Criar Dimensão de Produtos (DimProduct)
*/
IF OBJECT_ID('DimProduct', 'U') IS NOT NULL
    DROP TABLE DimProduct;

SELECT 
    ProductID,
    p.Name AS ProductName,
    ProductNumber,
    Color,
    StandardCost,
    ListPrice,
    Size,
    Weight,
    pc.Name AS ProductCategory
INTO DimProduct
FROM SalesLT.Product p
	Inner Join [SalesLT].[ProductCategory] pc
		On p.ProductCategoryID = pc.ProductCategoryID;


/*
	2. Criar Dimensão de Clientes (DimCustomer)
*/
IF OBJECT_ID('DimCustomer', 'U') IS NOT NULL
    DROP TABLE DimCustomer;

SELECT 
    CustomerID,             
    ModifiedDate
INTO DimCustomer
FROM SalesLT.Customer;


/*	
	3. Criar Dimensão de Datas (DimDate)
		Uma tabela de datas pode ser criada de forma derivada. Vamos gerar datas para análise com base nos registros de OrderDate.
*/

-- Definir variáveis de início e fim
DECLARE @StartDate DATE = (SELECT MIN(OrderDate) FROM SalesLT.SalesOrderHeader);
DECLARE @EndDate DATE = '2008-12-31';

-- Criar tabela para armazenar as datas
IF OBJECT_ID('DimDate', 'U') IS NOT NULL
    DROP TABLE DimDate;

CREATE TABLE DimDate (
    Date DATE PRIMARY KEY,
    Year INT,
    Month INT,
    Day INT,
    Weekday NVARCHAR(20),
    WeekOfYear INT,
    Quarter INT
);

-- Inserir datas na tabela
DECLARE @CurrentDate DATE = @StartDate;

WHILE @CurrentDate <= @EndDate
BEGIN
    INSERT INTO DimDate
    VALUES (
        @CurrentDate,
        YEAR(@CurrentDate),
        MONTH(@CurrentDate),
        DAY(@CurrentDate),
        DATENAME(WEEKDAY, @CurrentDate),
        DATEPART(WEEK, @CurrentDate),
        DATEPART(QUARTER, @CurrentDate)
    );
    SET @CurrentDate = DATEADD(DAY, 1, @CurrentDate);
END;



/*
 * 	4. Criar Tabela de Fatos de Vendas (FactSales)
 */
IF OBJECT_ID('FactSales', 'U') IS NOT NULL
    DROP TABLE FactSales;

SELECT 
    SOD.SalesOrderID,
    SOD.SalesOrderDetailID,
    SOD.ProductID,
    SOD.OrderQty,
    SOD.UnitPrice,
    SOD.UnitPriceDiscount,
    SOD.LineTotal,
    SOH.CustomerID,
    SOH.OrderDate,
    SOH.DueDate,
    SOH.ShipDate
INTO FactSales
FROM SalesLT.SalesOrderDetail SOD
JOIN SalesLT.SalesOrderHeader SOH
    ON SOD.SalesOrderID = SOH.SalesOrderID;


/*
	A consulta a seguir calcula a receita total por ano e território:
*/

SELECT 
    DD.Month,
	DD.Year,
    SUM(FS.LineTotal) AS ReceitaTotal
FROM FactSales FS
JOIN DimDate DD
    ON FS.OrderDate = DD.Date
GROUP BY 
    DD.Month,
	DD.Year
ORDER BY 
    DD.Month,
	DD.Year,
    ReceitaTotal DESC;


SELECT 
    DD.Month,
	DD.Year,    
	P.ProductCategory,
    SUM(FS.LineTotal) AS ReceitaTotal
FROM FactSales FS
JOIN DimDate DD
    ON FS.OrderDate = DD.Date
JOIN [dbo].[DimProduct] P
	ON FS.ProductID = P.ProductID
GROUP BY 
    DD.Month,
	DD.Year,
	P.ProductCategory    
ORDER BY 
    DD.Month,
	DD.Year,
	P.ProductCategory,
    ReceitaTotal DESC;

