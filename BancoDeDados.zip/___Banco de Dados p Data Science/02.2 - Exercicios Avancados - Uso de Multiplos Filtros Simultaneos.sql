

/*
	📌Exercício 01: Selecionar pedidos filtrando múltiplas condições
	Objetivo: Obter pedidos (SalesOrderHeader) que atendam aos 
		seguintes critérios:
	
		- O pedido foi feito a partir de 2008 (OrderDate '2008-01-01')
		
		- O pedido foi feito para um cliente cujo ID está entre 20000 e 30000
		- O envio foi feito via (ShipMethod) 'CARGO TRANSPORT 5' E 
			a conta do cliente não está bloqueada (OnlineOrderFlag = 0)
			
		- O TotalDue está acima de 1000 OU foi faturado (Status 5)
*/
Select
	SalesOrderID,
	OrderDate,
	CustomerID,
	TotalDue,
	Status,
	ShipMethod,
	OnlineOrderFlag
From SalesLT.SalesOrderHeader
Where 
	OrderDate >= '2008-01-01' -- 32
	AND CustomerID Between 20000 AND 30000 -- 23
	AND ShipMethod = 'CARGO TRANSPORT 5' -- 23
	AND OnlineOrderFlag = 0 -- 23
	AND (TotalDue > 1000 OR Status = 5) -- 23








/*
	📌Exercício 02: Selecionar produtos com critérios avançados
	Objetivo: Filtrar os produtos (SalesLT.Product) que atendam aos 
		seguintes critérios:
		
		- O produto tem cor definida (não pode faltar valor de cor)
		
		- O produto NÃO é preto (Color <> 'Black')
		
		- O produto deve ter um número (ProductNumber) que começa com 'BK'
		
		- O preço de lista (ListPrice) é maior que 500 OU o custo padrão (StandardCost) é 
				maior que 200
				
		- O peso está entre 1kg e 10kg OU a categoria do produto (ProductCategoryID) é 
				4 ou 5
  
*/
-- 295
Select 
	listprice,
	standardcost,
	weight
From SalesLT.Product
Where 
	Color IS NOT Null -- 245
	AND Color != 'Black' -- 156
	AND ProductNumber LIKE 'BK%' -- 67
	AND (ListPrice > 783.000 OR StandardCost > 487.000) -- 42
	AND (Weight Between 1000 AND 10000 OR ProductCategoryID IN(4,5) ) -- 30











