CREATE SCHEMA Curso;

CREATE TABLE Curso.Turma (
    TurmaID INT IDENTITY(1,1) PRIMARY KEY, -- Identificador único da turma
    Nome VARCHAR(100) NOT NULL -- Nome da turma
);

CREATE TABLE Curso.Aula (
    AulaID INT IDENTITY(1,1) PRIMARY KEY, -- Identificador único da aula
    TurmaID INT NOT NULL, -- Chave estrangeira da turma
    Data DATETIME NOT NULL, -- Data e horário da aula
    Titulo VARCHAR(255) NOT NULL, -- Título da aula
    Comentario VARCHAR(1000) NULL, -- Comentário opcional
    Ocorrencia BIT NOT NULL DEFAULT 0, -- Indica se a aula ocorreu (0 = não, 1 = sim)
    CONSTRAINT FK_Aula_Turma FOREIGN KEY (TurmaID) REFERENCES Curso.Turma(TurmaID) ON DELETE CASCADE
);

CREATE TABLE Curso.Aluno (
    AlunoID INT IDENTITY(1,1) PRIMARY KEY, -- Identificador único do aluno
    Nome VARCHAR(255) NOT NULL, -- Nome do aluno
    Email VARCHAR(255) UNIQUE NOT NULL, -- E-mail único para cada aluno
    DataNascimento DATE NOT NULL, -- Data de nascimento do aluno
    TurmaID INT NOT NULL, -- Chave estrangeira para associar à turma
    CONSTRAINT FK_Aluno_Turma FOREIGN KEY (TurmaID) REFERENCES Curso.Turma(TurmaID) ON DELETE CASCADE
);


--
-- Inserindo algumas turmas
INSERT INTO Curso.Turma (Nome) VALUES ('Turma SQL Básico'), ('Turma SQL Avançado');

-- Inserindo aulas vinculadas às turmas
INSERT INTO Curso.Aula (TurmaID, Data, Titulo, Comentario, Ocorrencia) 
VALUES 
    (1, '2025-02-25 10:00:00', 'Introdução ao SQL', 'Primeira aula da turma.', 1),
    (1, '2025-02-26 10:00:00', 'Cláusulas SQL', 'Explicação sobre WHERE e ORDER BY.', 0),
    (2, '2025-03-01 09:00:00', 'Funções de Agregação', 'Uso de SUM, AVG, etc.', 1);

-- Inserindo alunos vinculados a turmas
INSERT INTO Curso.Aluno (Nome, Email, DataNascimento, TurmaID) 
VALUES 
    ('João Silva', 'joao@email.com', '2000-05-10', 1),
    ('Maria Souza', 'maria@email.com', '1998-08-20', 1),
    ('Carlos Lima', 'carlos@email.com', '1995-12-15', 2);

SELECT 
    A.AulaID, A.Titulo, A.Data, A.Comentario, A.Ocorrencia, 
    T.TurmaID, T.Nome AS NomeTurma
FROM Curso.Aula A
JOIN Curso.Turma T ON A.TurmaID = T.TurmaID;



