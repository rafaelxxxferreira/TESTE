
Exercícios com GROUP BY

1. Contar o número de produtos por categoria:
Liste o ID da categoria e a quantidade de produtos em cada uma.


2. Calcular o total de vendas por Produto
Mostre o total de vendas (LineTotal) por Produto (ProductID).


3. Obter a média do preço padrão por categoria:
Liste o ID da categoria e a média do preço padrão (ListPrice) dos produtos em cada categoria.


4. Encontrar o número de produtos por faixa de preço:
Classifique os produtos em faixas de preço (ListPrice) e conte quantos produtos estão em cada faixa:

Preço < 100: Faixa "Barato"
Preço entre 100 e 500: Faixa "Moderado"
Preço > 500: Faixa "Caro"
