/*
	Como filtrar linhas no SQL
	Múltiplos filtros simultâneos
	Operador AND (todas as condições devem ser
						atendidas)
*/

Select 
	(ListPrice - StandardCost) as MargemLucro,
	*
From SalesLT.Product
Where ListPrice >= 1200 AND Color = 'Black'
	and (ListPrice - StandardCost) > 500
	
	
/*
	Como filtrar linhas no SQL
	Múltiplos filtros simultâneos
	Operador OR (ao menos uma condição deve ser	atendida)
*/
Select 
	(ListPrice - StandardCost) as MargemLucro,
	*
From SalesLT.Product
Where ListPrice >= 1200 OR Color = 'Black'
	OR (ListPrice - StandardCost) > 500	
	
	
	
	
/*
	1200 - 1900		-> mandatório
	Black ou Bike	
	
*/
Select 
	*
From SalesLT.Product
Where 
	ListPrice Between 1200 And 1900 
	And ( Color = 'Black' Or Name Like '%Bike%' )
	
	


	
	


