/*
 	Tratamento de Dados
 		- formato datas (datetime)
*/


/*
 * 	1. Contar pedidos por ano
 */

SELECT 
	YEAR(OrderDate) as Ano, 
	count(*) as TotalPedidos
FROM SalesLT.SalesOrderHeader soh 
GROUP BY 
	YEAR(OrderDate)
	
/*
 * 	2. Identificar a data do primeiro e último pedido
 */
SELECT 
	c.FirstName,
	MIN(OrderDate) AS PrimeiraDataPedido,
	MAX(OrderDate) AS UltimaDataPedido
FROM SalesLT.SalesOrderHeader soh 
	JOIN SalesLT.Customer c 
		ON soh.CustomerID = c.CustomerID
GROUP BY 
	c.FirstName
	

/*
 * 	3. Contar pedidos por DIA da SEMANA
 */

SELECT 
	DATENAME(WEEKDAY, OrderDate) as DiaSemana, 
	count(*) as TotalPedidos
FROM SalesLT.SalesOrderHeader soh 
GROUP BY DATENAME(WEEKDAY, OrderDate)


SELECT 
	DATEPART(QUARTER, OrderDate) as Trimestre, 
	count(*) as TotalPedidos
FROM SalesLT.SalesOrderHeader soh 
GROUP BY DATEPART(QUARTER, OrderDate)

SELECT 
	DATEDIFF(DAY, OrderDate, ShipDate) AS DiasParaEntrega, 
	count(*) as TotalPedidos
FROM SalesLT.SalesOrderHeader soh 
GROUP BY DATEDIFF(DAY, OrderDate, ShipDate)

-- Contar pedidos nos últimos 30 dias
SELECT 	 
	count(*) as TotalPedidosUltimos30Dias
FROM SalesLT.SalesOrderHeader soh 
WHERE OrderDate >= DATEADD(DAY,-30, GETDATE() ) 



	




