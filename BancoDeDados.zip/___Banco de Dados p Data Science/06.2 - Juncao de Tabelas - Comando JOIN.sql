-- Cliente
SELECT 
	CustomerID,
	FirstName,
	EmailAddress,
	Phone 
FROM SalesLT.Customer c 

-- Resumo Pedido
SELECT 
	SalesOrderID,
	OrderDate,
	CustomerID,
	TotalDue 
FROM SalesLT.SalesOrderHeader soh 

-- Cliente e Pedido
SELECT 
	c.CustomerID,
	FirstName,
	EmailAddress,
	Phone,
	SalesOrderID,
	OrderDate,
	TotalDue 
FROM SalesLT.Customer c 
	JOIN SalesLT.SalesOrderHeader soh 
		ON c.CustomerID = soh.CustomerID 
