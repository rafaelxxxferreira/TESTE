
/*
	Exercício 1: 
		Média de vendas por produto
		Calcule a média de quantidade de vendas por produto.
*/
SELECT 
	p.ProductID,
	p.Name AS ProductName,	
	AVG(OrderQty) as AverageQuantitySold 
FROM SalesLT.SalesOrderDetail sod 
	JOIN SalesLT.Product p
		ON sod.ProductID = p.ProductID 
GROUP BY 
	p.ProductID, 
	p.Name
ORDER BY AVG(OrderQty) DESC 




/*
	Exercício 2: Total de vendas por ano e mês
		Liste o total de vendas (em valor) por ano e mês.
*/
SELECT 
	YEAR(OrderDate) AS Ano,
	MONTH(OrderDate) AS Mes,	
	SUM(LineTotal) AS TotalVendas
FROM SalesLT.SalesOrderHeader soh
	JOIN SalesLT.SalesOrderDetail sod 
		ON soh.SalesOrderID = sod.SalesOrderID 
GROUP BY 
	YEAR(OrderDate),
	MONTH(OrderDate)

/*
	Exemplo 3: Produtos mais vendidos por categoria
	Liste os produtos mais vendidos de cada categoria.
*/
SELECT 
	p.Name AS nomeproduto, 
	pc.Name AS nomecategoria,
	SUM(orderQty) AS TotalVendas	
FROM SalesLT.SalesOrderDetail sod 
	JOIN SalesLT.Product p 
		ON sod.ProductID = p.ProductID
	JOIN SalesLT.ProductCategory pc 
		ON p.ProductCategoryID = pc.ProductCategoryID
GROUP BY 
	p.Name, 
	pc.Name
ORDER BY 
	pc.Name,
	p.Name 
	
	
		
	
	
	
	
	
	
	
	
