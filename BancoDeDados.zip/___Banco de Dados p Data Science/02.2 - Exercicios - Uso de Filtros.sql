


/*	
	Exercício 1) 
		Encontrar pedidos com valor total maior que 5000:
		Liste os pedidos cujo valor total devido (TotalDue) seja maior que 5000.

		SELECT SalesOrderID, TotalDue 
		FROM SalesLT.SalesOrderHeader 
		WHERE TotalDue > 5000;

	
	Exercício 2) 
		Exibir produtos com custo entre 10 e 50$:
		Liste os produtos cujo estoque disponível (SafetyStockLevel) esteja entre 10 e 50.
		
		SELECT *
		FROM SalesLT.Product 
		WHERE StandardCost BETWEEN 10 AND 50;

	
	Exercício 3) 
		Filtrar clientes pelo nome da empresa:
		Liste os clientes cuja empresa tenha "Bike" no nome.

		SELECT CustomerID, CompanyName 
		FROM Sales.Customer 
		WHERE CompanyName LIKE '%Bike%';

	Exercício 4)
		Filtrar produtos com margem de lucro negativa:
		Liste os produtos cujo custo padrão (StandardCost) seja maior que o preço padrão (ListPrice).
		
		SELECT ProductID, Name, StandardCost, ListPrice 
		FROM SalesLT.Product 
		WHERE StandardCost > ListPrice;

	Exercício 5)
		Filtrar clientes atualizados entre 01/01/2009 e 31-12-2009

		Select
			*
		From [SalesLT].Customer
		Where ModifiedDate >= '2009-01-01' AND ModifiedDate <= '2009-12-31' 

*/