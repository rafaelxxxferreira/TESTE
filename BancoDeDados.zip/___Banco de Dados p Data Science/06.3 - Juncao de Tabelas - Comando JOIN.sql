-- Resumo Pedido
SELECT 
	SalesOrderID,
	OrderDate,
	CustomerID,
	SubTotal,	
	TotalDue	
FROM SalesLT.SalesOrderHeader soh 

-- Itens Pedido
SELECT 
	SalesOrderID,
	SalesOrderDetailID,
	ProductID,
	LineTotal 
FROM SalesLT.SalesOrderDetail sod 

-- Resumo Pedido e Itens do Pedido
SELECT 
	soh.SalesOrderID,
	OrderDate,
	CustomerID,
	SubTotal,
	TotalDue,
	SalesOrderDetailID,
	ProductID,
	UnitPriceDiscount,
	OrderQty,
	UnitPrice, 
	LineTotal
FROM SalesLT.SalesOrderHeader soh 
	JOIN SalesLT.SalesOrderDetail sod 
		ON soh.SalesOrderID = sod.SalesOrderID