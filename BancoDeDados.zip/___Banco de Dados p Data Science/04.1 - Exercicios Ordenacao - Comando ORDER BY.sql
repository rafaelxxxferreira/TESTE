/*
	➡️ Exercícios: Ordenação

	Exercício 1) 
	Listar produtos em ordem alfabética:
	Exiba os nomes dos produtos organizados em ordem alfabética.
*/

SELECT ProductID, Name 
FROM SalesLT.Product 
ORDER BY Name ASC;

/*
	Exercício 2)
	Exibir produtos pelo preço mais alto:
	Liste os produtos organizados pelo preço padrão (ListPrice) do mais caro ao mais barato.
*/
SELECT Name, ListPrice 
FROM SalesLT.Product 
ORDER BY ListPrice DESC;

/*
	Exercício 3) 
	Encontrar os 5 produtos mais caros:
*/

SELECT TOP 5 Name, ListPrice 
FROM SalesLT.Product 
ORDER BY ListPrice DESC;

/*
	Exercício 4) 
	Ordenar clientes pelo território em ordem decrescente:
	Liste os clientes organizados pelo TerritoryID em ordem decrescente.
*/

SELECT CustomerID, TerritoryID 
FROM SalesLT.Customer 
ORDER BY TerritoryID DESC;

/*
	Exercício 5)
	Ordenar pedidos pelo valor total devido:
	Liste os pedidos organizados em ordem crescente pelo valor total devido (TotalDue).
*/

SELECT SalesOrderID, TotalDue 
FROM Sales.SalesOrderHeader 
ORDER BY TotalDue ASC;

/*
	Exercício 6)
	Organizar produtos por categoria e preço:
	Liste os produtos organizados primeiro pela categoria do produto (ProductCategoryID) em ordem crescente e, dentro de cada categoria, pelo preço padrão (ListPrice) em ordem decrescente.
*/

SELECT ProductID, Name, ProductCategoryID, ListPrice 
FROM SalesLT.Product 
ORDER BY ProductCategoryID ASC, ListPrice DESC;

/*
	Exercício 7)
	Exibir produtos com base na diferença entre preço e custo:
	Liste os produtos organizados pela diferença entre o preço padrão (ListPrice) e o custo padrão (StandardCost) em ordem decrescente.
*/

SELECT ProductID, Name, ListPrice, StandardCost, (ListPrice - StandardCost) AS MargemLucro 
FROM SalesLT.Product 
ORDER BY MargemLucro DESC;