/*
	Como filtrar linhas no SQL
	Exemplo Numérico
*/
Select 
	*
From [SalesLT].[Product]
where ListPrice > 1200


/*
	Como filtrar linhas no SQL
	Exemplo Texto
*/
Select 
	*
From [SalesLT].[Product]
Where Color = 'Black'


/*
	Como filtrar linhas no SQL
	Exemplo Texto utilizando LIKE
*/
Select 
	*
From [SalesLT].[Product]
Where Name LIKE '%Bike'

/*
	Como filtrar linhas no SQL
	Exemplo Texto utilizando LIKE
*/
Select 
	*
From [SalesLT].[Product]
Where Name LIKE 'Bike%'

/*
	Como filtrar linhas no SQL
	Exemplo Texto utilizando LIKE
*/
Select 
	*
From [SalesLT].[Product]
Where Name LIKE '%Bike%'

/*
	Como filtrar linhas no SQL
	Exemplo Texto utilizando NOT LIKE
*/
Select 
	*
From [SalesLT].[Product]
Where Name NOT LIKE '%Bike%'


/*
	Como filtrar linhas no SQL
	Utilizando o Operador IN
*/
Select 
	*
From [SalesLT].[Product]
Where Color IN('Black','White')

/*
	Como filtrar linhas no SQL
	Utilizando o Operador IN
*/
Select 
	*
From [SalesLT].[Product]
Where ProductID IN(680,748)


/*
	Como filtrar linhas no SQL
	Utilizando o Operador NOT IN
*/
Select 
	*
From [SalesLT].[Product]
Where Color NOT IN('Black','White')

/*
	Como filtrar linhas no SQL
	Utilizando o Operador IN
*/
Select 
	*
From [SalesLT].[Product]
Where ProductID NOT IN(680,748)


/*
	Como filtrar linhas no SQL
	Valores Nulos e Booleanos
*/
Select 
	*
From [SalesLT].[Product]
Where Color IS NULL
