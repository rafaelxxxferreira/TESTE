/*
 * 1. Contar pedidos por ano
 *	Liste o total de pedidos feitos a cada ano.
 */

SELECT 
    YEAR(OrderDate) AS Ano, 
    COUNT(SalesOrderID) AS TotalPedidos
FROM SalesLT.SalesOrderHeader
GROUP BY YEAR(OrderDate)
ORDER BY Ano;


/*
 * 2. Obter pedidos por mês em um ano específico
 * 	Liste o total de pedidos realizados em cada mês do ano de 2023.
 */

SELECT 
    MONTH(OrderDate) AS Mes, 
    COUNT(SalesOrderID) AS TotalPedidos
FROM SalesLT.SalesOrderHeader
WHERE YEAR(OrderDate) = 2008
GROUP BY MONTH(OrderDate)
ORDER BY Mes;


/*
	3. Identificar a data do primeiro e último pedido
	Encontre a data do primeiro e do último pedido na base.
*/

SELECT 
    MIN(OrderDate) AS PrimeiraDataPedido,
    MAX(OrderDate) AS UltimaDataPedido
FROM SalesLT.SalesOrderHeader;


/*
	4. Contar pedidos por dia da semana
	Liste o número total de pedidos feitos em cada dia da semana.
*/

SELECT 
    DATENAME(WEEKDAY, OrderDate) AS DiaDaSemana, 
    COUNT(SalesOrderID) AS TotalPedidos
FROM SalesLT.SalesOrderHeader
GROUP BY DATENAME(WEEKDAY, OrderDate)
ORDER BY TotalPedidos DESC;


/*
	5. Calcular o tempo médio de envio
	Calcule o tempo médio (em dias) entre a data do pedido (OrderDate) e a data de envio (ShipDate).
*/

SELECT 
    AVG(DATEDIFF(DAY, OrderDate, ShipDate)) AS TempoMedioEnvioDias
FROM SalesLT.SalesOrderHeader
WHERE ShipDate IS NOT NULL;


/*
	6. Identificar os pedidos atrasados
	Liste os pedidos que demoraram mais de 7 dias entre a data do pedido e a data de envio.
*/

SELECT 
    SalesOrderID, 
    OrderDate, 
    ShipDate, 
    DATEDIFF(DAY, OrderDate, ShipDate) AS DiasParaEnvio
FROM SalesLT.SalesOrderHeader
WHERE DATEDIFF(DAY, OrderDate, ShipDate) > 7;


/*
	7. Calcular o total de vendas por trimestre
	Agrupe os pedidos por trimestre e calcule o total de vendas (TotalDue) para cada um.
*/

SELECT 
    DATEPART(QUARTER, OrderDate) AS Trimestre, 
    SUM(TotalDue) AS TotalVendas
FROM SalesLT.SalesOrderHeader
GROUP BY DATEPART(QUARTER, OrderDate)
ORDER BY Trimestre;


/*
	8. Analisar tendências de vendas em um período específico
	Liste o total de vendas (TotalDue) em cada mês durante o ano de 2023.
*/

SELECT 
    FORMAT(OrderDate, 'yyyy-MM') AS MesAno, 
    SUM(TotalDue) AS TotalVendas
FROM SalesLT.SalesOrderHeader
WHERE YEAR(OrderDate) = 2008
GROUP BY FORMAT(OrderDate, 'yyyy-MM')
ORDER BY MesAno;

/*
	9. Contar pedidos nos últimos 30 dias
	Conte o número total de pedidos realizados nos últimos 30 dias.
*/

SELECT 
    COUNT(SalesOrderID) AS TotalPedidosUltimos30Dias
FROM SalesLT.SalesOrderHeader
WHERE OrderDate >= DATEADD(DAY, -30, GETDATE());


/*
	10. Analisar sazonalidade de vendas
	Liste o total de vendas (TotalDue) por mês, considerando todos os anos.
*/

SELECT 
    MONTH(OrderDate) AS Mes, 
    SUM(TotalDue) AS TotalVendas
FROM SalesLT.SalesOrderHeader
GROUP BY MONTH(OrderDate)
ORDER BY Mes;


/*
	11. Identificar o cliente com maior tempo entre pedidos
	Liste os clientes e o maior intervalo (em dias) entre dois pedidos consecutivos.
*/

WITH Pedidos AS (
    SELECT 
        CustomerID, 
        OrderDate, 
        ROW_NUMBER() OVER (PARTITION BY CustomerID ORDER BY OrderDate) AS OrdemPedido
    FROM SalesLT.SalesOrderHeader
)
SELECT 
    p1.CustomerID, 
    MAX(DATEDIFF(DAY, p1.OrderDate, p2.OrderDate)) AS MaiorIntervaloDias
FROM Pedidos p1
JOIN Pedidos p2 
    ON p1.CustomerID = p2.CustomerID AND p1.OrdemPedido = p2.OrdemPedido - 1
GROUP BY p1.CustomerID
ORDER BY MaiorIntervaloDias DESC;


/*
	12. Contar pedidos no fim de semana
	Liste o número total de pedidos realizados em fins de semana.
*/

SELECT 
    COUNT(SalesOrderID) AS TotalPedidosFimDeSemana
FROM SalesLT.SalesOrderHeader
WHERE DATENAME(WEEKDAY, OrderDate) IN ('Saturday', 'Sunday');
