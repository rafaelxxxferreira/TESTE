
/*
➡️ Exercícios: Selecionando Colunas
O gabarito está em anexo, e as resoluções em vídeo estão nas próximas aulas.

Exercício 1) Considere o conjunto de dados [SalesLT].[SalesOrderHeader]. Você deve recuperar informações básicas sobre os pedidos. Escreva uma consulta SQL usando apenas as cláusulas SELECT e FROM para exibir as seguintes colunas:

CustomerID
SalesOrderID
OrderDate
Totaldue

Sua consulta deve recuperar essas informações para todos os registros no conjunto de dados.

Exercício 2) Considere o conjunto de dados [SalesLT].[SalesOrderHeader]. Escreva uma consulta SQL usando apenas as cláusulas SELECT e FROM para recuperar as seguintes informações:

SalesOrderID
ShipMethod
Totaldue

Exercício 3) Usando o conjunto de dados [SalesLT].[Customer], escreva uma consulta SQL usando apenas as cláusulas SELECT e FROM para exibir as seguintes colunas:

FirstName
LastName
EmailAddress
Phone

Exercício 4) A análise eficaz dos dados de vendas é crucial para otimizar as estratégias de negócio. A ausência de insights abrangentes sobre o desempenho das vendas limita a capacidade de tomar decisões informadas sobre gerenciamento de estoque e campanhas de marketing.

Obter dados essenciais de vendas é o primeiro passo. Utilizando o schema [SalesLT], crie uma consulta que exiba as colunas: SalesOrderID, ProductID, OrderQty e LineTotal da tabela 'SalesOrderDetail'."
*/

SELECT TOP (1000) 
	SalesOrderID,
	OrderDate,
	CustomerID,
	Totaldue
FROM [SalesLT].[SalesOrderHeader]

SELECT TOP (1000) 
	SalesOrderID,
	ShipMethod,
	Totaldue
FROM [SalesLT].[SalesOrderHeader]

SELECT TOP (1000) 
	FirstName,
	LastName,
	EmailAddress,
	Phone
FROM [SalesLT].[Customer]

SELECT TOP (1000) 
	SalesOrderID, 
	ProductID, 
	OrderQty, 
	LineTotal
FROM [SalesLT].[SalesOrderDetail]

